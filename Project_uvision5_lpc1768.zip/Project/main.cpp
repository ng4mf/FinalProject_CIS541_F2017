#include <stdio.h>
#include <stdlib.h>
#include <time.h>

#include "mbed.h"

#define MAXWAIT 150
#define MINWAIT 120

//Here p10 and p11 are the pins for connecting heart and pacemaker's mbeds, can change it if required
DigitalOut PIN1(p10);
DigitalOut PIN2(p11);
     
int main() {
    
    Timer t;
    
    // Use current time as seed for random generator
    srand(time(0));
    //Generate a random number between MINWAIT and MAXWAIT as heart should beat(if it beats naturally) randomly between MIN and MAX wait
    int random_no = (rand() % (MAXWAIT - MINWAIT + 1)) + MINWAIT;
    //printf("Rand no. is: %d\n", random_no);
    
    //Start a timer
    t.start();
    int begin = t.read_ms();
    
    while(true){
        label:
        //If time in milli-seconds is greater(due to time taken in executing other commands) or equal to the random number then
        //send the sensing signal to the pacemaker
        if(t.read_ms()-begin > random_no || t.read_ms()-begin == random_no){
            //printf("Time passed is: %d\n", t.read_ms()-begin);
            //Send sensing signal
            PIN2 = true;
            //Wait for 1 ms to turn the PIN2 off to make sure pacemaker got this signal, this value can be changed later based on max 
            //communication delay between heart and the pacemaker's mbeds
            wait(0.001);
            PIN2 = false; 
            //Change the random no. now
            random_no = (rand() % (MAXWAIT - MINWAIT + 1)) + MINWAIT;
            //printf("New rand no. is: %d\n", random_no);
            t.reset();
            begin = t.read_ms();
            goto label;
        }  
        
        //If a pacing signal was send by pacemaker, then reset the timer and start the next cycle
        if(PIN1){
            //printf("PIN1 is true\n");
            t.reset();
            begin = t.read_ms();
            goto label;
        } 
    }

    //Stop the timer
    t.stop();
}
